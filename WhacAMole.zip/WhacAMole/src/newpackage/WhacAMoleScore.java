package newpackage;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.DOMException;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class WhacAMoleScore {
 
    private final String playerName;
    private final int score;
 
    public WhacAMoleScore(String playerName, int score) {
        this.playerName = playerName;
        this.score = score;
    }
 
    public String getPlayerName() {
        return playerName;
    }
 
    public int getScore() {
        return score;
    }
 


public void saveHighScoreToXml(String fileName, int newScore) {
    DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
    try {
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
 
        // root elements
        org.w3c.dom.Document doc = docBuilder.newDocument();
        org.w3c.dom.Element rootElement = doc.createElement("whacamole-score");
        doc.appendChild(rootElement);
 
        // player elements
        org.w3c.dom.Element player = doc.createElement("player");
        rootElement.appendChild(player);
 
        // name element
        org.w3c.dom.Element name = doc.createElement("name");
        player.appendChild(name);
        name.appendChild(doc.createTextNode(this.playerName));
 
        // score element
        org.w3c.dom.Element score = doc.createElement("score");
        player.appendChild(score);
        score.appendChild(doc.createTextNode(String.valueOf(this.score)));
 
        // comapre new score and existing scores
        org.w3c.dom.Document docExisting = docBuilder.parse(fileName);
        NodeList existingScores = docExisting.getElementsByTagName("score");
        boolean isHighScore = false;
        for (int i = 0; i < existingScores.getLength(); i++) {
            int currentScore = Integer.parseInt(existingScores.item(i).getTextContent());
            if (newScore > currentScore) {
                isHighScore = true;
                break;
            }
        }
 
        if (isHighScore) {
            // write the content into xml file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(fileName));
            transformer.transform(source, result);
        }
    } catch (IOException | NumberFormatException | ParserConfigurationException | TransformerException | DOMException | SAXException e) {
    }
}
}
