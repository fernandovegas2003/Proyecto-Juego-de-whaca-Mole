package newpackage;

import java.awt.Color;
import java.awt.Image;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Creature extends JButton {

    private static final int MIN_LIFE = 50;
    private static final int MAX_LIFE = 80;
    static Random rand = new Random(); //declare Random statically so it does not have to be re-initiated for each use 
    static int SIZE;
    private boolean isAlive; //shows whether creature is alive or not 
    private int life_count; //shows how long the creature has currently been alive if applicable 
    private int final_life; //stores how long the creature will be alive for this life

    public Creature() {
        isAlive = false;
        Color marron = new Color(139, 69, 19);
        this.setBackground(marron);
        this.setIcon(new ImageIcon(new ImageIcon("C:\\Users\\Jean\\Desktop\\PROYECTO ANALISIS\\PrototipoWhacAMole\\src\\newpackage\\folder\\huecoSinTopo1.png").getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT)));
        //this.setSize(20, 20);
        this.setFocusPainted(false); //disable the painting of focus
        this.setBorderPainted(false); // disable the painting of border
        this.setContentAreaFilled(false); //disable the painting of background
        life_count = 0;

    }

    //return whether the creature is alive or not 
    public boolean getIsAlive() {
        return isAlive;
    }
    

    public void revive() {
        if (!isAlive) {
            final_life = MIN_LIFE + rand.nextInt(MAX_LIFE - MIN_LIFE + 1); //set final life 
            isAlive = true; //set creature as being alive  
            Color marron = new Color(139, 69, 19);
            this.setBackground(marron);
            this.setIcon(new ImageIcon(new ImageIcon("C:\\Users\\Jean\\Desktop\\PROYECTO ANALISIS\\PrototipoWhacAMole\\src\\newpackage\\folder\\topoHueco1.png").getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT)));
            this.setOpaque(false);
            this.setContentAreaFilled(false);
            this.setBorderPainted(false);
            this.setFocusPainted(false); //disable the painting of focus
        }

    }

    //Precondition: creature must be alive 
    //set the creature as no longer being alive, change the background color back to being 
    //red, reset the life count, and decrement the game's creature alive count 
    public void kill() {
        isAlive = false;
        Color marron = new Color(139, 69, 19);
        this.setBackground(marron);
        this.setIcon(new ImageIcon(new ImageIcon("C:\\Users\\Jean\\Desktop\\PROYECTO ANALISIS\\PrototipoWhacAMole\\src\\newpackage\\folder\\huecoSinTopo1.png").getImage().getScaledInstance(300, 300, Image.SCALE_DEFAULT)));
        this.setOpaque(false);
        this.setContentAreaFilled(false);
        this.setBorderPainted(false);
        this.setFocusPainted(false); //disable the painting of focus
        life_count = 0;
        Game.creaturesAlive--;
    }

    //if creature is alive increment its life_count and if the life count is equal to its max_life re_set it to being dead
    public void update() {
        if (isAlive) {
            life_count++;

            //if life_count is equal to max_life kill the creature 
            if (life_count == final_life) {
                this.kill();
            }
        }
    }
}